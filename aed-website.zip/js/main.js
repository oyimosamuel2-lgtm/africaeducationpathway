/* AED African Education Pathway — interactions */
(function () {
  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => [...c.querySelectorAll(s)];

  // Preloader -> kick off hero animations
  const finishLoad = () => {
    $('#preloader')?.classList.add('hide');
    document.body.classList.add('loaded');
  };
  window.addEventListener('load', () => setTimeout(finishLoad, 350));
  setTimeout(finishLoad, 3000); // fallback

  // Year
  $('#year').textContent = new Date().getFullYear();

  // Header state, progress bar, back-to-top, hero parallax
  const header = $('#header');
  const progress = $('#scrollProgress');
  const toTop = $('#toTop');
  const heroBg = $('.hero-bg');
  let ticking = false;

  const onScroll = () => {
    const y = window.scrollY;
    const max = document.documentElement.scrollHeight - window.innerHeight;
    header.classList.toggle('scrolled', y > 40);
    progress.style.transform = `scaleX(${max > 0 ? y / max : 0})`;
    toTop.classList.toggle('show', y > 600);
    if (heroBg && y < window.innerHeight) heroBg.style.translate = `0 ${y * 0.3}px`;
    ticking = false;
  };
  window.addEventListener('scroll', () => {
    if (!ticking) { requestAnimationFrame(onScroll); ticking = true; }
  }, { passive: true });
  onScroll();

  toTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

  // Mobile menu
  const burger = $('#burger');
  const nav = $('#nav');
  const toggleMenu = (open) => {
    nav.classList.toggle('open', open);
    burger.classList.toggle('open', open);
    burger.setAttribute('aria-expanded', open);
    document.body.classList.toggle('no-scroll', open);
  };
  burger.addEventListener('click', () => toggleMenu(!nav.classList.contains('open')));
  $$('a', nav).forEach(a => a.addEventListener('click', () => toggleMenu(false)));
  document.addEventListener('keydown', e => { if (e.key === 'Escape') toggleMenu(false); });

  // Reveal on scroll
  const revealIO = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('in');
        revealIO.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15, rootMargin: '0px 0px -40px 0px' });
  $$('.reveal').forEach(el => revealIO.observe(el));

  // Active nav link
  const links = $$('.nav-link');
  const sectionIO = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        links.forEach(l => l.classList.toggle('active', l.getAttribute('href') === '#' + entry.target.id));
      }
    });
  }, { rootMargin: '-45% 0px -50% 0px' });
  $$('main section[id]').forEach(s => sectionIO.observe(s));

  // Contact form -> opens email client (works on static hosting like GitHub Pages)
  const form = $('#contactForm');
  const note = $('#formNote');
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    let valid = true;
    $$('[required]', form).forEach(field => {
      const wrap = field.closest('.field');
      const ok = field.checkValidity();
      wrap.classList.toggle('error', !ok);
      if (!ok) valid = false;
    });
    if (!valid) {
      note.textContent = 'Please fill in the highlighted fields.';
      note.classList.remove('ok');
      return;
    }
    const d = Object.fromEntries(new FormData(form));
    const subject = `Study abroad enquiry – ${d.name} (${d.level}, ${d.destination})`;
    const body =
      `Name: ${d.name}\nEmail: ${d.email}\nPhone: ${d.phone || '-'}\n` +
      `Study level: ${d.level}\nPreferred destination: ${d.destination}\n\n${d.message}`;
    window.location.href =
      `mailto:aedafricaneducationpathway@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    note.textContent = 'Thank you! Your email app should open with your message ready to send.';
    note.classList.add('ok');
    form.reset();
  });
  $$('input, textarea, select', form).forEach(f =>
    f.addEventListener('input', () => f.closest('.field').classList.remove('error'))
  );
})();
